if ds_list_find_index(global.ds_saveroom, id) != -1 && !did
	exit;

if sprite_index != spr_secretportal_enter
{
	reset_anim(spr_secretportal_enter)
	secret_cutscene = true
	fmod_studio_event_instance_oneshot_3d("event:/sfx/misc/secretenter", x, y)
}

other.target_room = "secret" //prevents the lap portal from breaking shit

do_hold_player(true)
