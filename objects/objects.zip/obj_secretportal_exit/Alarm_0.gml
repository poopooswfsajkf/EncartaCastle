reset_anim(spr_secretportal_spawnclose)
secret_cutscene = true